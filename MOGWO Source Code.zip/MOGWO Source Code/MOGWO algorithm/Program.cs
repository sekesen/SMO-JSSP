﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Diagnostics;
using System.Runtime.Remoting.Lifetime;

namespace MOGWO
{
    class Solution
    {
        public double Energy, Tardiness;
        public int[] Sequence;
        public int[] Hız;
        public Solution(int A)
        {
            Sequence = new int[Program.job_no * Program.machine_no];
            Hız = new int[Sequence.Length];
            for (int i = 0; i < Sequence.Length; i++)
            {
                Sequence[i] = Program.chromo[A, 0, i];
                Hız[i] = Program.chromo[A, 2, i];
            }
            Energy = Program.totalEnergyConsumption[A];
            Tardiness = Program.totalTardiness[A];
        }
        public Solution()
        {
            Sequence = new int[Program.job_no * Program.machine_no];
            Hız = new int[Sequence.Length];
        }

    }
    internal class Program
    {
        public static int[,] job_sequence;
        public static Random rand;
        public static int job_no, machine_no, selected_speed, populationSize, offspringSize, populationSizewithOffspring, maxGeneration, alfa, beta, delta, ArchiveLimit;
        static int[] Threshold;
        static int[] Due_date;
        static int[] instant_standby;
        static int[,] instant_proces;
        static int[,] processing_time;
        public static int[,,] chromo;
        static int[] OperNum;
        static int[] speed;
        static double mutationRate;
        // Arrays to store objective values
        public static double[] totalEnergyConsumption;
        public static double[] totalTardiness;
        static double[] crowdingDistance;
        static List<List<int>> fronts; // To store Pareto fronts
        static HashSet<int> selectedParents = new HashSet<int>();
        static Stopwatch CPU = new Stopwatch();
        static List<Solution> Archive = new List<Solution>();
        static Dictionary<int, List<int>> Grid = new Dictionary<int, List<int>>();
        static double maxEnergy = 0;
        static double minEnergy = 0;
        static double maxTardiness = 0;
        static double minTardiness = 0;
        public static Solution AlfaKurt, BetaKurt, DeltaKurt;
        static double[] hızdizisi = { 1, 1.1, 1.3 };


        static void Main(string[] args)
        {
            string Yol = Path.Combine(System.Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Hüseyin Bozkurt Deneyler", "Problems");
            string Yol2 = Path.Combine(System.Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Hüseyin Bozkurt Deneyler", "Solutions");
            string[] Problems = Directory.GetFiles(Yol);

            foreach (string DosyaYol in Problems)
            {
                string[] TempArray = DosyaYol.Split('\\');
                string FileName = TempArray[TempArray.Length - 1];
                Console.WriteLine(FileName + " çözülüyor...");
                FileName = FileName.Substring(0, FileName.Length - 4) + "_Solution_GWO.txt";
                FileName = Path.Combine(Yol2, FileName);
                StreamWriter Yaz = new StreamWriter(FileName);
                Yaz.WriteLine("Seed;SolNo;Energy;Tardiness;CPU");
                for (int run = 1; run <= 10; run++)
                {
                    rand = new Random(run);

                    //Yaz.WriteLine("Seed = " + run);
                    //Yaz.WriteLine("=========================================");

                    DosyaOku(DosyaYol);

                    CPU.Reset();
                    CPU.Start();

                    OperNum = new int[job_no * machine_no];
                    maxGeneration = OperNum.Length*15;
                    populationSize = OperNum.Length*15;
                    mutationRate = 1;
                    offspringSize = 1;
                    ArchiveLimit = job_no*machine_no*4;// (job_no + machine_no) * 100;
                    populationSizewithOffspring = populationSize + offspringSize;
                    Archive.Clear();

                    // Initialize arrays to store objective values
                    totalEnergyConsumption = new double[populationSizewithOffspring];
                    totalTardiness = new double[populationSizewithOffspring];

                    // Creating 3D array storing "Operation sequence + Machines assignments + Speed levels assignments"
                    chromo = new int[populationSizewithOffspring, 3, OperNum.Length];

                    //Initializing operation sequence
                    int ind = 0;
                    for (int i = 1; i <= job_no; i++)
                        for (int k = 1; k <= machine_no; k++)
                            OperNum[ind++] = i;


                    ConstructInitialPopulation();



                    //crowdingDistance = new double[populationSizewithOffspring];  // Initialize crowding distance array

                    //int[] iyileşmecount = new int[populationSize];

                    for (int generation = 0; generation < maxGeneration; generation++)
                    {

                        //Select alfa beta delta

                        SelectLeaders();

                        //Console.WriteLine("Seed: " + run + "\tGeneration: " + generation);
                        //Console.WriteLine("Alfa: " + alfa + "\tEnergy: " + totalEnergyConsumption[alfa] + "\tTardiness: " + totalTardiness[alfa]);
                        //Console.WriteLine("Beta: " + beta + "\tEnergy: " + totalEnergyConsumption[beta] + "\tTardiness: " + totalTardiness[beta]);
                        //Console.WriteLine("Delta: " + delta + "\tEnergy: " + totalEnergyConsumption[delta] + "\tTardiness: " + totalTardiness[delta] + "\n");

                        //SelectPAretnts
                        //SelectParents();


                        int[][] offspringArray = new int[offspringSize][]; // Array for offspring operations
                        int[][] offspringSpeedsArray = new int[offspringSize][]; // Array for offspring speeds

                        for (int i = 0; i < populationSize; i++) // crossover for each omega wolf
                        {
                            Solution parentA;
                            int parentB = 0;


                            double x = rand.NextDouble();
                            if (x <= 0.33)
                                parentA = AlfaKurt;
                            else if (x <= 0.66)
                                parentA = BetaKurt;
                            else
                                parentA = DeltaKurt;

                            parentB = i;

                            // Initialize operation and speed chromosomes for parents
                            int[] parentAChromosome = new int[OperNum.Length];
                            int[] parentBChromosome = new int[OperNum.Length];
                            int[] parentASpeeds = new int[OperNum.Length]; // Speed array for parent 1
                            int[] parentBSpeeds = new int[OperNum.Length]; // Speed array for parent 2



                            for (int j = 0; j < OperNum.Length; j++)
                            {
                                parentAChromosome[j] = parentA.Sequence[j]; // Operation numbers for parent1
                                parentBChromosome[j] = chromo[parentB, 0, j]; // Operation numbers for parent2
                                parentASpeeds[j] = parentA.Hız[j]; // Speeds for parent1
                                parentBSpeeds[j] = chromo[parentB, 2, j]; // Speeds for parent2
                            }

                            double crossoverType = rand.NextDouble();
                            if (crossoverType < 0.333)
                            {
                                // Perform cycle crossover on operation sequences, including speeds
                                int[][] offspring = CycleCrossover(parentAChromosome, parentBChromosome, parentASpeeds, parentBSpeeds);

                                // Store offspring results in the arrays
                                offspringArray[0] = offspring[0];
                                offspringSpeedsArray[0] = offspring[1];
                            }
                            else if (crossoverType < 0.666)
                            {
                                // Now perform single-point crossover on speeds from offspringSpeeds and reverseOffspringSpeeds
                                int[][] newOffspringSpeeds = SinglePointCrossover(parentAChromosome, parentBChromosome, parentASpeeds, parentBSpeeds);
                                offspringArray[0] = parentAChromosome;
                                offspringSpeedsArray[0] = newOffspringSpeeds[0];
                            }
                            else
                            {
                                int[][] twiceOffsprings = TwiceCrossover(parentAChromosome, parentBChromosome, parentASpeeds, parentBSpeeds);
                                offspringArray[0] = twiceOffsprings[0];
                                offspringSpeedsArray[0] = twiceOffsprings[1];
                            }

                            //Storing offsprings to population
                            for (int ii = 0; ii < OperNum.Length; ii++)
                            {
                                chromo[populationSize, 0, ii] = offspringArray[0][ii];
                                chromo[populationSize, 2, ii] = offspringSpeedsArray[0][ii];
                            }

                            //Calculating objectives of new position of omega wolf i                       
                            CalculateOBJ(populationSize);

                            if (Dominates(i, populationSize))
                            {
                                // Applying Mutation
                                double MutationType = rand.NextDouble();
                                if (MutationType < 0.333)
                                {
                                    Mutate(offspringArray[0]);
                                }
                                else if (MutationType < 0.666)
                                {
                                    Mutate(offspringSpeedsArray[0]);
                                }
                                else
                                {
                                    Mutate(offspringArray[0]);
                                    Mutate(offspringSpeedsArray[0]);
                                }
                                //MutateNew(offspringSpeedsArray[0]);
                            }

                            //Storing offsprings to population
                            for (int ii = 0; ii < OperNum.Length; ii++)
                            {
                                chromo[populationSize, 0, ii] = offspringArray[0][ii];
                                chromo[populationSize, 2, ii] = offspringSpeedsArray[0][ii];
                            }

                            //Calculating objectives of new position of omega wolf i                       
                            CalculateOBJ(populationSize);

                            if (Dominates(populationSize, i))
                            {
                                //Storing offsprings to population
                                for (int ii = 0; ii < OperNum.Length; ii++)
                                {
                                    chromo[i, 0, ii] = chromo[populationSize, 0, ii];
                                    chromo[i, 2, ii] = chromo[populationSize, 2, ii];
                                }
                                //iyileşmecount[i]++;
                                //Console.WriteLine("Generation: "+generation + "\t" + i + "İYİLEŞTİ");
                                CalculateOBJ(i);
                            }
                            //else if (!Dominates(populationSize, i) && !Dominates(i, populationSize))
                            //{
                            //    double xx = rand.NextDouble();
                            //    xx = 1;
                            //    if (xx < 0.5)
                            //    {
                            //        for (int ii = 0; ii < OperNum.Length; ii++)
                            //        {
                            //            chromo[i, 0, ii] = chromo[populationSize, 0, ii];
                            //            chromo[i, 2, ii] = chromo[populationSize, 2, ii];
                            //        }
                            //        //Console.WriteLine("Generation: " + generation + "\t" + i + "yenilendi");
                            //        CalculateOBJ(i);
                            //    }

                            //}
                            Solution Çözüm = new Solution(populationSize);
                            UpdateArchive(Archive, Çözüm);



                        }






                        //Perfrom regenration
                        //Regenerate(fronts);

                    }

                    //Console.WriteLine("EN SON SONUÇLAR");
                    Archive.Sort((x, y) => x.Energy.CompareTo(y.Energy));
                    CPU.Stop();
                    for (int j = 0; j < Archive.Count; j++)
                    {
                        //Yaz.WriteLine($"  Number {j} - Energy: {Archive[j].Energy}, Tardiness: {Archive[j].Tardiness}");
                        Yaz.WriteLine($"{run};{j};{Archive[j].Energy};{Archive[j].Tardiness};{CPU.Elapsed.ToString()}");
                    }


                    

                    //Front 1'deki benzersiz sonuçlar










                    //Yaz.WriteLine("CPU=" + CPU.Elapsed.ToString());
                    //Yaz.WriteLine();

                    //for (int i = 0; i < populationSize; i++)
                    //{
                    //    Console.WriteLine(i + "\t" + iyileşmecount[i]);
                    //}
                }
                Yaz.Close();
            }


            Console.WriteLine("HESAPLAMA BİTTİ");
            Console.ReadLine();

        }

        // Cycle crossover method
        static int[][] CycleCrossover(int[] parentA, int[] parentB, int[] speedsA, int[] speedsB)
        {
            int operCount = parentA.Length; // Number of operations
            int[] offspring = new int[operCount];
            int[] offspringSpeeds = new int[operCount]; // To store offspring speeds

            // Initialize offspring with -1 (indicating empty spots)
            for (int i = 0; i < operCount; i++)
            {
                offspring[i] = -1;
                offspringSpeeds[i] = -1; // Initialize speeds with -1 as well
            }

            // Step 1: Calculate ranks for both parents (for operation sequence)
            //Console.WriteLine("\nStep 1: Calculate ranks for both parents (Operation Sequence)");

            // Calculate ranks for Operation Sequence - Parent A
            int[] ranksA = CalculateRanks(parentA);


            // Calculate ranks for Operation Sequence - Parent B
            int[] ranksB = CalculateRanks(parentB);

            //// Print Parent A (Operation Sequence) and their Ranks
            //Console.WriteLine("\nParent A:");
            //for (int i = 0; i < parentA.Length; i++)
            //{
            //    Console.Write(parentA[i] + " ");
            //}
            //Console.WriteLine();

            //Console.WriteLine("Ranks of Parent A:");
            //for (int i = 0; i < ranksA.Length; i++)
            //{
            //    Console.Write(ranksA[i] + " ");
            //}
            //Console.WriteLine();

            //Console.WriteLine("Speeds of Parent A:");
            //for (int i = 0; i < speedsA.Length; i++)
            //{
            //    Console.Write(speedsA[i] + " ");
            //}
            //Console.WriteLine();

            //// Print Parent B (Operation Sequence) and their Ranks
            //Console.WriteLine("\nParent B:");
            //for (int i = 0; i < parentB.Length; i++)
            //{
            //    Console.Write(parentB[i] + " ");
            //}
            //Console.WriteLine();

            //Console.WriteLine("Ranks of Parent B:");
            //for (int i = 0; i < ranksB.Length; i++)
            //{
            //    Console.Write(ranksB[i] + " ");
            //}
            //Console.WriteLine();

            //Console.WriteLine("Speeds of Parent B:");
            //for (int i = 0; i < speedsB.Length; i++)
            //{
            //    Console.Write(speedsB[i] + " ");
            //}
            //Console.WriteLine();


            // Step 2: Select a substring from Parent A
            //Console.WriteLine("\nStep 2: Select substring from Parent A");
            int Point1, Point2;
            int start, end;

            do
            {
                Point1 = rand.Next(0, OperNum.Length);
                Point2 = rand.Next(0, OperNum.Length);
            } while ((Point1 == Point2) || (Point1 == 0 && Point2 == OperNum.Length) || (Point1 == OperNum.Length && Point2 == 0));

            if (Point1 < Point2)
            { start = Point1; end = Point2; }
            else { start = Point2; end = Point1; }

            // End position for substring
            int substringLength = end - start + 1;

            // Selected Substring for Operation Sequence
            int[] selectedSubstring = new int[substringLength];
            int[] selectedRanks = new int[substringLength];

            for (int i = 0; i < substringLength; i++)
            {
                selectedSubstring[i] = parentA[start + i];
                selectedRanks[i] = ranksA[start + i];
            }

            //// Print selected substring for Operation Sequence
            //Console.WriteLine("Selected Substring from Parent A):");
            //for (int i = 0; i < selectedSubstring.Length; i++)
            //{
            //    Console.Write(selectedSubstring[i] + " ");
            //}
            //Console.WriteLine();

            //// Print ranks of the selected substring for Operation Sequence
            //Console.WriteLine("Ranks of Selected Substring:");
            //for (int i = 0; i < selectedRanks.Length; i++)
            //{
            //    Console.Write(selectedRanks[i] + " ");
            //}
            //Console.WriteLine();

            // Step 3: Determine remaining genes from Parent B for Operation Sequence
            //Console.WriteLine("\nStep 3: Determine which genes to delete from Parent B");

            // Step 3.1: Count the remaining genes first

            int[] remainingGenes = new int[0];


            for (int i = 0; i < parentB.Length; i++)
            {
                bool isInSelectedSubstring = false;
                for (int j = 0; j < selectedSubstring.Length; j++)
                {
                    if (parentB[i] == selectedSubstring[j] && ranksB[i] == selectedRanks[j])
                    {
                        isInSelectedSubstring = true;
                        break;
                    }
                }

                if (!isInSelectedSubstring)
                {

                    Array.Resize(ref remainingGenes, remainingGenes.Length + 1);
                    remainingGenes[remainingGenes.Length - 1] = parentB[i];    // Store remaining gene

                }
            }
            //// Step 3.2: Print the remaining genes
            //Console.Write("Remaining Genes from Parent B: ");
            //for (int i = 0; i < remainingGenes.Length; i++)
            //{
            //    Console.Write(remainingGenes[i] + " ");
            //}
            //Console.WriteLine();

            //// Step 4: Fix selected substring in offspring and fill remaining from Parent B
            //Console.WriteLine("\nStep 4: Fix selected substring in offspring and fill remaining from Parent B");

            // Step 4.1: Fill the offspring with the selected substring from Parent A
            for (int i = start; i <= end; i++)
            {
                offspring[i] = parentA[i];

            }
            // Step 4.2: Fill the remaining genes in the offspring with those from Parent B
            int remainingIndex = 0;
            for (int i = 0; i < offspring.Length; i++)
            {
                if (offspring[i] == -1) // Empty spots in the offspring
                {
                    offspring[i] = remainingGenes[remainingIndex];

                    remainingIndex++;
                }
            }

            // Step 4.3: Calculate ranks for the offspring operation sequence
            int[] ranksOffspring = new int[offspring.Length];
            int[] rankCountOffspring = new int[offspring.Max() + 1]; // Ensure it can hold all possible values

            for (int i = 0; i < offspring.Length; i++)
            {
                rankCountOffspring[offspring[i]]++; // Increment the count of this gene
                ranksOffspring[i] = rankCountOffspring[offspring[i]]; // Assign the current count as the rank
            }

            // Step 5: Assign speed from Parent A or Parent B based on rank and parent source 
            for (int i = 0; i < offspring.Length; i++)
            {
                int geneValue = offspring[i];     // The gene value in the offspring
                int geneRank = ranksOffspring[i]; // The rank of the gene in the offspring

                bool fromParentA = (i >= start && i <= end); // If gene is within the selected substring from Parent A

                if (fromParentA)
                {
                    // Gene comes from Parent A (because it's within the selected substring)
                    for (int j = 0; j < parentA.Length; j++)
                    {
                        // Find the matching gene in Parent A by both value and rank
                        if (parentA[j] == geneValue && ranksA[j] == geneRank)
                        {
                            offspringSpeeds[i] = speedsA[j]; // Assign speed from Parent A
                            break;
                        }
                    }
                }
                else
                {
                    // Gene comes from Parent B (because it's from the remaining genes)
                    for (int j = 0; j < parentB.Length; j++)
                    {
                        // Find the matching gene in Parent B by both value and rank
                        if (parentB[j] == geneValue && ranksB[j] == geneRank)
                        {
                            offspringSpeeds[i] = speedsB[j]; // Assign speed from Parent B
                            break;
                        }
                    }
                }
            }

            //// Print the final offspring and their speeds
            //Console.WriteLine("Offspring (Operation Sequence):");
            //for (int i = 0; i < offspring.Length; i++)
            //{
            //    Console.Write(offspring[i] + " ");
            //}
            //Console.WriteLine();

            //// Print the ranks of the offspring
            //Console.WriteLine("Ranks of Offspring (Operation Sequence):");
            //for (int i = 0; i < ranksOffspring.Length; i++)
            //{
            //    Console.Write(ranksOffspring[i] + " ");
            //}
            //Console.WriteLine();

            //// Print offspring speeds
            //Console.WriteLine("Offspring (Speed):");
            //for (int i = 0; i < offspringSpeeds.Length; i++)
            //{
            //    Console.Write(offspringSpeeds[i] + " ");
            //}
            //Console.WriteLine();

            return new int[][] { offspring, offspringSpeeds }; // Return both offspring and speeds

        }

        // Single-point crossover method for offspringSpeeds and reverseOffspringSpeeds
        static int[][] SinglePointCrossover(int[] ParentAchr, int[] ParentBchr, int[] ParentAspd, int[] ParentBspd)
        {
            //Sanal hız vektörü
            int[] TempParentAspd = new int[ParentAspd.Length];
            int[] TempParentBspd = new int[ParentBspd.Length];
            int[] RankA = CalculateRanks(ParentAchr);
            int[] RankB = CalculateRanks(ParentBchr);
            for (int i = 0; i < ParentAspd.Length; i++)
            {
                TempParentAspd[(ParentAchr[i] - 1) * machine_no + RankA[i] - 1] = ParentAspd[i];
                // Tempspd[(1-1)*3+1-1]
                TempParentBspd[(ParentBchr[i] - 1) * machine_no + RankB[i] - 1] = ParentBspd[i];
            }




            // Choose a random crossover point (between 1 and length - 1 to avoid no swap)
            int crossoverPoint = rand.Next(1, TempParentAspd.Length - 1);

            //Console.WriteLine("\nSingle-Point Crossover Point: " + crossoverPoint);

            // Create two offspring by swapping at the crossover point
            int[] newOffspring1Speeds = new int[TempParentAspd.Length];

            int[] TempnewOffspring1Speeds = new int[TempParentAspd.Length];


            // Fill new offspring arrays based on the crossover point
            for (int i = 0; i < TempParentAspd.Length; i++)
            {
                if (i < crossoverPoint)
                {
                    TempnewOffspring1Speeds[i] = TempParentAspd[i]; // Copy from first offspring speeds until crossover point

                }
                else
                {
                    TempnewOffspring1Speeds[i] = TempParentBspd[i]; // Copy from second offspring after crossover point

                }
            }
            for (int i = 0; i < TempParentAspd.Length; i++)
            {
                newOffspring1Speeds[i] = TempnewOffspring1Speeds[(ParentAchr[i] - 1) * machine_no + RankA[i] - 1];

            }


            // Return the new offspring speeds arrays
            return new int[][]
            {
                    newOffspring1Speeds,
            };

        }

        //Cycle crossover without speed
        static int[] CycleCrossoverWithoutSpeed(int[] parentA, int[] parentB)
        {
            int operCount = parentA.Length; // Number of operations
            int[] offspring = new int[operCount];

            // Initialize offspring with -1 (indicating empty spots)
            for (int i = 0; i < operCount; i++)
            {
                offspring[i] = -1;

            }

            // Step 1: Calculate ranks for both parents (for operation sequence)
            //Console.WriteLine("\nStep 1: Calculate ranks for both parents (Operation Sequence)");

            // Calculate ranks for Operation Sequence - Parent A
            int[] ranksA = CalculateRanks(parentA);

            // Calculate ranks for Operation Sequence - Parent B
            int[] ranksB = CalculateRanks(parentB);



            // Step 2: Select a substring from Parent A
            //Console.WriteLine("\nStep 2: Select substring from Parent A");
            int Point1, Point2;
            int start, end;

            do
            {
                Point1 = rand.Next(0, OperNum.Length);
                Point2 = rand.Next(0, OperNum.Length);
            } while ((Point1 == Point2) || (Point1 == 0 && Point2 == OperNum.Length) || (Point1 == OperNum.Length && Point2 == 0));

            if (Point1 < Point2)
            { start = Point1; end = Point2; }
            else { start = Point2; end = Point1; }
            int substringLength = end - start + 1;

            // Selected Substring for Operation Sequence
            int[] selectedSubstring = new int[substringLength];
            int[] selectedRanks = new int[substringLength];

            for (int i = 0; i < substringLength; i++)
            {
                selectedSubstring[i] = parentA[start + i];
                selectedRanks[i] = ranksA[start + i];
            }

            //// Print selected substring for Operation Sequence
            //Console.WriteLine("Selected Substring from Parent A):");
            //for (int i = 0; i < selectedSubstring.Length; i++)
            //{
            //    Console.Write(selectedSubstring[i] + " ");
            //}
            //Console.WriteLine();

            //// Print ranks of the selected substring for Operation Sequence
            //Console.WriteLine("Ranks of Selected Substring:");
            //for (int i = 0; i < selectedRanks.Length; i++)
            //{
            //    Console.Write(selectedRanks[i] + " ");
            //}
            //Console.WriteLine();

            //// Step 3: Determine remaining genes from Parent B for Operation Sequence
            //Console.WriteLine("\nStep 3: Determine which genes to delete from Parent B");

            // Step 3.1: Count the remaining genes first

            int[] remainingGenes = new int[0];


            for (int i = 0; i < parentB.Length; i++)
            {
                bool isInSelectedSubstring = false;
                for (int j = 0; j < selectedSubstring.Length; j++)
                {
                    if (parentB[i] == selectedSubstring[j] && ranksB[i] == selectedRanks[j])
                    {
                        isInSelectedSubstring = true;
                        break;
                    }
                }

                if (!isInSelectedSubstring)
                {

                    Array.Resize(ref remainingGenes, remainingGenes.Length + 1);
                    remainingGenes[remainingGenes.Length - 1] = parentB[i];    // Store remaining gene

                }
            }
            //// Step 3.2: Print the remaining genes
            //Console.Write("Remaining Genes from Parent B: ");
            //for (int i = 0; i < remainingGenes.Length; i++)
            //{
            //    Console.Write(remainingGenes[i] + " ");
            //}
            //Console.WriteLine();

            //// Step 4: Fix selected substring in offspring and fill remaining from Parent B
            //Console.WriteLine("\nStep 4: Fix selected substring in offspring and fill remaining from Parent B");

            // Step 4.1: Fill the offspring with the selected substring from Parent A
            for (int i = start; i <= end; i++)
            {
                offspring[i] = parentA[i];

            }
            // Step 4.2: Fill the remaining genes in the offspring with those from Parent B
            int remainingIndex = 0;
            for (int i = 0; i < offspring.Length; i++)
            {
                if (offspring[i] == -1) // Empty spots in the offspring
                {
                    offspring[i] = remainingGenes[remainingIndex];

                    remainingIndex++;
                }
            }

            //// Print the final offspring
            //Console.WriteLine("Offspring (Operation Sequence):");
            //for (int i = 0; i < offspring.Length; i++)
            //{
            //    Console.Write(offspring[i] + " ");
            //}
            //Console.WriteLine();            
            return offspring;

        }

        //Single point crossover fot twice
        static int[] SinglePointCrossoverForTwice(int[] ParentAchr, int[] ParentBchr, int[] ParentAspd, int[] ParentBspd, int[] Off1)
        {
            //Sanal hız vektörü
            int[] TempParentAspd = new int[ParentAspd.Length];
            int[] TempParentBspd = new int[ParentBspd.Length];
            int[] RankA = CalculateRanks(ParentAchr);
            int[] RankB = CalculateRanks(ParentBchr);
            for (int i = 0; i < ParentAspd.Length; i++)
            {
                TempParentAspd[(ParentAchr[i] - 1) * machine_no + RankA[i] - 1] = ParentAspd[i];
                // Tempspd[(1-1)*3+1-1]
                TempParentBspd[(ParentBchr[i] - 1) * machine_no + RankB[i] - 1] = ParentBspd[i];
            }




            // Choose a random crossover point (between 1 and length - 1 to avoid no swap)
            int crossoverPoint = rand.Next(1, TempParentAspd.Length - 1);

            //Console.WriteLine("\nSingle-Point Crossover Point: " + crossoverPoint);

            // Create two offspring by swapping at the crossover point
            int[] newOffspring1Speeds = new int[TempParentAspd.Length];

            int[] TempnewOffspring1Speeds = new int[TempParentAspd.Length];


            // Fill new offspring arrays based on the crossover point
            for (int i = 0; i < TempParentAspd.Length; i++)
            {
                if (i < crossoverPoint)
                {
                    TempnewOffspring1Speeds[i] = TempParentAspd[i]; // Copy from first offspring speeds until crossover point

                }
                else
                {
                    TempnewOffspring1Speeds[i] = TempParentBspd[i]; // Copy from second offspring after crossover point

                }
            }

            int[] RankOff1 = CalculateRanks(Off1);

            for (int i = 0; i < TempParentAspd.Length; i++)
            {
                newOffspring1Speeds[i] = TempnewOffspring1Speeds[(Off1[i] - 1) * machine_no + RankOff1[i] - 1];

            }


            // Return the new offspring speeds arrays
            return newOffspring1Speeds;



        }

        //Twice crossover
        static int[][] TwiceCrossover(int[] parentA, int[] parentB, int[] speedsA, int[] speedsB)
        {
            int[] off1 = CycleCrossoverWithoutSpeed(parentA, parentB);

            int[] spd = SinglePointCrossoverForTwice(parentA, parentB, speedsA, speedsB, off1);


            return new int[][]
            {
               off1,spd
            };
        }


        // Mutation by swapping two elements in the array
        static void Mutate(int[] array)
        {

            // Check if mutation should occur at this array based on mutationRate
            if (rand.NextDouble() < mutationRate)
            {

                //Console.WriteLine("\nMutation performed");
                // Choose two random indexes to swap 
                int swappoint = rand.Next(1, array.Length - 1); ;

                int[] temp1 = new int[swappoint];
                int[] temp2 = new int[array.Length - swappoint];

                for (int i = 0; i < swappoint; i++)
                    temp1[i] = array[i];
                for (int i = 0; i < temp2.Length; i++)
                    temp2[i] = array[i + swappoint];

                for (int i = 0; i < array.Length; i++)
                {
                    if (i < temp2.Length)
                        array[i] = temp2[i];
                    else array[i] = temp1[i - temp2.Length];
                }

            }
        }

        static void MutateNew(int[] array)
        {

            // Check if mutation should occur at this array based on mutationRate
            if (rand.NextDouble() < mutationRate)
            {

                //Console.WriteLine("\nMutation performed");
                // Choose two random indexes to swap 
                int elements = array.Length / 2;

                for (int i = 0; i < elements; i++)
                {
                    int indis = rand.Next(0, array.Length);
                    array[indis] = (array[indis] % 3) + 1;
                }


            }
        }
        static void Shuffle(int[] dizi)
        {

            for (int i = 0; i < dizi.Length / 2; i++)
            {
                int x = rand.Next(i, dizi.Length);
                int gecici = dizi[i];
                dizi[i] = dizi[x];
                dizi[x] = gecici;
            }
            //foreach (int j in dizi)
            //{
            //    Console.Write(j + " ");
            //}
        }

        static void CalculateOBJ(int population)
        {
            //determining machine index

            int[] OrdLev = new int[job_no];
            for (int i = 0; i < OperNum.Length; i++)
            {
                int JobNumb = chromo[population, 0, i] - 1;
                int JobMach = job_sequence[JobNumb, OrdLev[JobNumb]];
                chromo[population, 1, i] = JobMach;
                OrdLev[JobNumb]++;

            }
            double[] lastJobFinishTime = new double[job_no];
            double[] lastMachineFinishTime = new double[machine_no];

            double totalEnergy = 0;
            double totalTardinessValue = 0;
            double energyProccess = 0, energyStandby = 0;

            for (int i = 0; i < OperNum.Length; i++)
            {
                int jobIndex = chromo[population, 0, i] - 1;
                int machineIndex = chromo[population, 1, i];
                int speedLevel = chromo[population, 2, i] - 1;

                double processingTime = Math.Round((double)processing_time[jobIndex, machineIndex] / hızdizisi[speedLevel], 5);
                int processingPower = instant_proces[machineIndex, speedLevel];

                double startTime = Math.Max(lastJobFinishTime[jobIndex], lastMachineFinishTime[machineIndex]);

                double idleTime = startTime - lastMachineFinishTime[machineIndex];
                if (idleTime > 0 && idleTime < Threshold[machineIndex] && lastMachineFinishTime[machineIndex] > 0)
                {
                    energyStandby += idleTime * instant_standby[machineIndex];
                }

                double finishTime = startTime + processingTime;
                double energyConsumed = processingTime * processingPower;
                energyProccess += energyConsumed;

                totalEnergy = energyProccess + energyStandby;

                lastJobFinishTime[jobIndex] = finishTime;
                lastMachineFinishTime[machineIndex] = finishTime;

                //Printing start and finish time of each operation
                //Console.Write(startTime + " ");
                //Console.Write(finishTime + " ");
            }

            // Calculating total tardiness 
            for (int j = 0; j < job_no; j++)
            {
                double tardiness = Math.Max(0, lastJobFinishTime[j] - Due_date[j]);
                totalTardinessValue += tardiness;
            }
            totalEnergy = Math.Round(totalEnergy, 2);

            //totalTardinessValue = Math.Round(totalTardinessValue, 2);
            //Console.WriteLine($"\nPopulation {population}: Total Energy = {totalEnergy}, Energy Process = {energyProccess}, Energy Standby = {energyStandby}, Total Tardiness = {totalTardinessValue}");

            totalEnergyConsumption[population] = Math.Round(totalEnergy, 2);
            totalTardiness[population] = Math.Round(totalTardinessValue, 2);
        }

        // Categorizing solutions from a population into different Pareto fronts based on dominance relationships.
        static List<List<int>> PerformNonDominatedSorting(int populationSize)
        {
            // (dominateCount) A list that tracking how many solutions dominate a given solution.
            List<int> dominatedCount = new List<int>(new int[populationSize]);
            List<List<int>> dominationSet = new List<List<int>>();

            for (int i = 0; i < populationSize; i++)
            {
                dominationSet.Add(new List<int>());
            }

            // (Fronts) A list of lists representing different Pareto fronts. Initially, the first front (rank 0) is an empty list.
            List<List<int>> fronts = new List<List<int>> { new List<int>() };


            // Loops for Dominance Comparison
            // Comparing each solution "p" against every other solution "q".
            for (int p = 0; p < populationSize; p++)
            {
                for (int q = 0; q < populationSize; q++)
                {
                    if (Dominates(p, q))
                    {
                        dominationSet[p].Add(q);
                    }
                    else if (Dominates(q, p))
                    {
                        dominatedCount[p]++;
                    }
                }

                if (dominatedCount[p] == 0)
                {
                    fronts[0].Add(p);
                }
            }

            // Assigning solutions to subsequent fronts
            int iFront = 0;
            while (fronts[iFront].Count > 0)
            {
                List<int> nextFront = new List<int>();
                foreach (int p in fronts[iFront])
                {
                    foreach (int q in dominationSet[p])
                    {
                        dominatedCount[q]--;
                        if (dominatedCount[q] == 0)
                        {
                            nextFront.Add(q);
                        }
                    }
                }

                iFront++;
                fronts.Add(nextFront);
            }

            return fronts;
        }

        // The function Dominates(p, q) returns true if solution p dominates solution q according to the two objectives: totalEnergyConsumption and totalTardiness.
        static bool Dominates(int p, int q)
        {
            bool betterOrEqualInAllObjectives = (totalEnergyConsumption[p] <= totalEnergyConsumption[q]) &&
                                                (totalTardiness[p] <= totalTardiness[q]);
            bool strictlyBetterInAtLeastOneObjective = (totalEnergyConsumption[p] < totalEnergyConsumption[q]) ||
                                                       (totalTardiness[p] < totalTardiness[q]);

            return betterOrEqualInAllObjectives && strictlyBetterInAtLeastOneObjective;
        }

        static bool ArchiveDomination(Solution p, Solution q)
        {
            bool betterOrEqualInAllObjectives = (p.Energy <= q.Energy) &&
                                                (p.Tardiness <= q.Tardiness);
            bool strictlyBetterInAtLeastOneObjective = (p.Energy < q.Energy) ||
                                                       (p.Tardiness < q.Tardiness);

            return betterOrEqualInAllObjectives && strictlyBetterInAtLeastOneObjective;
        }

        // segment of calculating crowding distance of each individual
        static double[][] CalculateCrowdingDistance(List<int> front, double[] totalEnergyConsumption, double[] totalTardiness, double largeValue)
        {
            int numberOfObjectives = 2; // Number of objectives
            double[][] contributions = new double[front.Count][];

            // Initialize contributions for each individual
            for (int i = 0; i < contributions.Length; i++)
            {
                contributions[i] = new double[numberOfObjectives]; // Contributions for objectives 0 and 1
            }

            // If there are only one or two individuals, assign the large value
            if (front.Count <= 2)
            {
                for (int i = 0; i < front.Count; i++)
                {
                    contributions[i][0] = largeValue; // Objective 0
                    contributions[i][1] = largeValue; // Objective 1
                }
                return contributions;
            }

            // Process objective 0 normally
            front.Sort((x, y) => totalEnergyConsumption[x].CompareTo(totalEnergyConsumption[y]));

            // Set boundary contributions to large value for objective 0
            contributions[0][0] = largeValue;
            contributions[front.Count - 1][0] = largeValue;

            // Calculate crowding distance for objective 0
            double minObjective0 = totalEnergyConsumption[front[0]];
            double maxObjective0 = totalEnergyConsumption[front[front.Count - 1]];

            // If all indivduals are equal, assign the large value
            if (minObjective0 == maxObjective0)
            {
                for (int i = 0; i < front.Count; i++)
                {
                    contributions[i][0] = largeValue; // Objective 0
                    contributions[i][1] = largeValue; // Objective 1
                }
                return contributions;
            }

            //Console.WriteLine($"\nObjective 0: min = {minObjective0}, max = {maxObjective0}");

            for (int i = 1; i < front.Count - 1; i++)
            {
                double nextObjective0 = totalEnergyConsumption[front[i + 1]];
                double prevObjective0 = totalEnergyConsumption[front[i - 1]];

                // Store contribution for the individual
                contributions[i][0] += (nextObjective0 - prevObjective0) / (maxObjective0 - minObjective0);
                //Console.WriteLine($"Individual {front[i]}: Contribution from objective 0 = {contributions[i][0]}");
            }
            for (int i = 0; i < front.Count - 1; i++)
            {
                double total = contributions[i][0];
                for (int j = i + 1; j < front.Count; j++)
                {
                    if (totalEnergyConsumption[front[j]] == totalEnergyConsumption[front[i]])
                    {
                        total += contributions[j][0];
                        total = total > largeValue ? largeValue : total;
                        if (j == front.Count - 1)
                            for (int k = i; k <= j; k++)
                                contributions[k][0] = total;

                    }
                    else
                    {
                        for (int k = i; k < j; k++)
                            contributions[k][0] = total;
                        i = j - 1;
                        break;

                    }
                }
            }

            // Reverse the front for objective 1 to ensure the individuals are in opposite order
            List<int> reverseFront = new List<int>(front);
            reverseFront.Reverse();

            // Set boundary contributions to large value for objective 1
            contributions[0][1] = largeValue;
            contributions[front.Count - 1][1] = largeValue;

            // Calculate crowding distance for objective 1
            double minObjective1 = totalTardiness[reverseFront[0]];
            double maxObjective1 = totalTardiness[reverseFront[reverseFront.Count - 1]];

            //Console.WriteLine($"\nObjective 1: min = {minObjective1}, max = {maxObjective1}");

            for (int i = 1; i < reverseFront.Count - 1; i++)
            {
                double nextObjective1 = totalTardiness[reverseFront[i + 1]];
                double prevObjective1 = totalTardiness[reverseFront[i - 1]];

                // Store contribution for the individual
                contributions[i][1] += (nextObjective1 - prevObjective1) / (maxObjective1 - minObjective1);
                //Console.WriteLine($"Individual {reverseFront[i]}: Contribution from objective 1 = {contributions[i][1]}");
            }
            for (int i = 0; i < front.Count - 1; i++)
            {
                double total = contributions[i][1];
                for (int j = i + 1; j < front.Count; j++)
                {
                    if (totalTardiness[reverseFront[j]] == totalTardiness[reverseFront[i]])
                    {
                        total += contributions[j][1];
                        total = total > largeValue ? largeValue : total;
                        if (j == front.Count - 1)
                            for (int k = i; k <= j; k++)
                                contributions[k][1] = total;

                    }
                    else
                    {
                        for (int k = i; k < j; k++)
                            contributions[k][1] = total;
                        i = j - 1;
                        break;

                    }
                }
            }

            return contributions;
        }
        // Helpfull adding for Tournment segment
        static int GetFrontIndex(int candidate, List<List<int>> fronts)
        {
            for (int i = 0; i < fronts.Count; i++)
            {
                if (fronts[i].Contains(candidate))
                {
                    return i; // Return the index of the front containing the candidate
                }
            }
            return -1; // If not found, which ideally should not happen
        }
        // Helpfull adding for Crossover segment
        static int GetParent(HashSet<int> selectedParents, int index)
        {
            int count = 0;
            foreach (var parent in selectedParents)
            {
                if (count == index)
                {
                    return parent;
                }
                count++;
            }
            return -1; // If not found, return -1 (should not happen if selectedParents are correctly managed)
        }

        static int[] CalculateRanks(int[] Parent)
        {
            // Calculate ranks for Operation Sequence - Parent A
            int maxGeneValueA = Parent.Max();
            int[] ranksA = new int[Parent.Length];
            int[] rankCountA = new int[maxGeneValueA + 1];
            for (int i = 0; i < Parent.Length; i++)
            {
                rankCountA[Parent[i]]++;
                ranksA[i] = rankCountA[Parent[i]];
            }

            return ranksA;
        }

        static void Regenerate(List<List<int>> Frontlar)
        {
            List<int> Giren = new List<int>();
            List<int> Çıkan = new List<int>();
            int eklenecek = populationSize;
            for (int i = 0; i < Frontlar.Count - 1; i++)
            {
                if (eklenecek == 0)
                {
                    for (int j = 0; j < Frontlar[i].Count; j++)
                        if (Frontlar[i][j] < populationSize)
                            Çıkan.Add(Frontlar[i][j]);

                }
                else
                {
                    if (Frontlar[i].Count <= eklenecek)
                    {
                        for (int j = 0; j < Frontlar[i].Count; j++)
                            if (Frontlar[i][j] >= populationSize)
                                Giren.Add(Frontlar[i][j]);
                        eklenecek -= Frontlar[i].Count;
                    }
                    else
                    {
                        //List<double> CrwDistances = new List<double>();
                        //for (int j = 0; j < Frontlar[i].Count; j++)
                        //    CrwDistances.Add(crowdingDistance[Frontlar[i][j]]);

                        Frontlar[i].Sort((x, y) => crowdingDistance[x].CompareTo(crowdingDistance[y]));
                        Frontlar[i].Reverse();
                        for (int j = 0; j < eklenecek; j++)
                            if (Frontlar[i][j] >= populationSize)
                                Giren.Add(Frontlar[i][j]);

                        for (int j = eklenecek; j < Frontlar[i].Count; j++)
                            if (Frontlar[i][j] < populationSize)
                                Çıkan.Add(Frontlar[i][j]);

                        eklenecek = 0;

                    }
                }
            }

            //birey aktarma
            for (int i = 0; i < Giren.Count; i++)
            {
                for (int j = 0; j < OperNum.Length; j++)
                {
                    chromo[Çıkan[i], 0, j] = chromo[Giren[i], 0, j];
                    chromo[Çıkan[i], 2, j] = chromo[Giren[i], 2, j];
                }

                totalEnergyConsumption[Çıkan[i]] = totalEnergyConsumption[Giren[i]];
                totalTardiness[Çıkan[i]] = totalTardiness[Giren[i]];
            }

            //Console.Write("\nGirenler: ");
            //for (int i = 0; i < Giren.Count; i++)
            //    Console.Write(Giren[i] + " ");
            //Console.Write("\nÇıkanlar: ");
            //for (int i = 0; i < Çıkan.Count; i++)
            //    Console.Write(Çıkan[i] + " ");
            //Console.WriteLine();
        }

        static void DosyaOku(string Adres)
        {
            string currentLine, text;
            string[] currentArray;
            StreamReader reader;

            reader = new StreamReader(Adres);

            // Reading the number of jobs
            currentLine = reader.ReadLine();
            currentArray = currentLine.Split('\t');
            job_no = int.Parse(currentArray[1]);

            // Reading the number of machines
            currentLine = reader.ReadLine();
            currentArray = currentLine.Split('\t');
            machine_no = int.Parse(currentArray[1]);

            // Reading the number of selectable speed levels 
            currentLine = reader.ReadLine();
            currentArray = currentLine.Split('\t');
            selected_speed = int.Parse(currentArray[1]);

            // Initialize arrays based on job_no and machine_no
            Threshold = new int[machine_no];
            Due_date = new int[job_no];
            instant_standby = new int[machine_no];
            instant_proces = new int[machine_no, selected_speed];
            processing_time = new int[job_no, machine_no];

            // Reading the threshold of each machine
            reader.ReadLine();
            for (int i = 0; i < machine_no; i++)
            {
                text = reader.ReadLine();
                Threshold[i] = Convert.ToInt32(text);
            }

            // Reading the due dates of each job
            reader.ReadLine();
            for (int i = 0; i < job_no; i++)
            {
                text = reader.ReadLine();
                Due_date[i] = Convert.ToInt32(text);
            }

            // Reading the stand-by instantaneous power of each machine 
            reader.ReadLine();
            for (int i = 0; i < machine_no; i++)
            {
                text = reader.ReadLine();
                instant_standby[i] = Convert.ToInt32(text);
            }

            // Reading the processing instantaneous power of each machine 
            reader.ReadLine();
            for (int i = 0; i < machine_no; i++)
            {
                string line = reader.ReadLine();
                string[] items = line.Split('\t');
                for (int j = 0; j < selected_speed; j++)
                {
                    instant_proces[i, j] = int.Parse(items[j]);
                }
            }

            // Reading the processing times of operations
            reader.ReadLine();
            for (int i = 0; i < job_no; i++)
            {
                string line = reader.ReadLine();
                string[] items = line.Split('\t');
                for (int j = 0; j < machine_no; j++)
                {
                    processing_time[i, j] = int.Parse(items[j]);
                }
            }

            // Reading the job sequencing on machines
            reader.ReadLine();
            job_sequence = new int[job_no, machine_no];
            for (int i = 0; i < job_no; i++)
            {
                string line = reader.ReadLine();
                string[] items = line.Split('\t');
                for (int j = 0; j < machine_no; j++)
                {
                    job_sequence[i, j] = int.Parse(items[j]) - 1;
                }
            }

            reader.Close();
        }

        static void ConstructInitialPopulation()
        {
            //Contructing initial population

            for (int population = 0; population < populationSize; population++)
            {
                //Console.WriteLine("\nPopoulation: " + population);
                Shuffle(OperNum);

                speed = new int[OperNum.Length];

                ////Deneme
                double x = rand.NextDouble();
                /*x = 1*/;
                if (x < 0.25)
                {
                    for (int i = 0; i < OperNum.Length; i++)
                        speed[i] = 1;

                }
                else if (x < 0.5)
                {
                    for (int i = 0; i < OperNum.Length; i++)
                        speed[i] = 2;
                }
                else if (x < 0.75)
                {
                    for (int i = 0; i < OperNum.Length; i++)
                        speed[i] = 3;
                }
                else
                {
                    for (int i = 0; i < OperNum.Length; i++)
                        speed[i] = rand.Next(1, selected_speed + 1);
                }
                //Deneme bitiş

                //for (int i = 0; i < OperNum.Length; i++)
                //{

                //    speed[i] = rand.Next(1, selected_speed + 1);
                //}

                for (int i = 0; i < OperNum.Length; i++)
                {
                    chromo[population, 0, i] = OperNum[i];
                    chromo[population, 2, i] = speed[i];
                }

                CalculateOBJ(population);
                Solution Çözüm = new Solution(population);
                UpdateArchive(Archive, Çözüm);
                //GridBelirle(Archive);
            }
        }

        static void UpdateArchive(List<Solution> Arşiv, Solution Çözüm)
        {
            if (Arşiv.Count == 0)
            {
                Arşiv.Add(Çözüm);
                maxEnergy = Çözüm.Energy;
                minEnergy = Çözüm.Energy;
                maxTardiness = Çözüm.Tardiness;
                minTardiness = Çözüm.Tardiness;
            }
            else
            {
                for (int i = 0; i < Arşiv.Count; i++)
                    if (ArchiveDomination(Arşiv[i], Çözüm) || (Arşiv[i].Energy == Çözüm.Energy && Arşiv[i].Tardiness == Çözüm.Tardiness))
                        return;
                List<int> Çıkacak = new List<int>();
                for (int i = 0; i < Arşiv.Count; i++)
                    if (ArchiveDomination(Çözüm, Arşiv[i]))
                        Çıkacak.Add(i);

                bool ReOrganize = false;
                List<int> KeysToRemove = new List<int>();
                for (int i = Çıkacak.Count - 1; i >= 0; i--)
                {
                    if (Arşiv[Çıkacak[i]].Energy == minEnergy || Arşiv[Çıkacak[i]].Energy == maxEnergy)
                        ReOrganize = true;
                    Arşiv.RemoveAt(Çıkacak[i]);

                    //foreach (var öge in Grid)
                    //{
                    //    int key = öge.Key;
                    //    List<int> liste = öge.Value;
                    //    if (liste.Contains(Çıkacak[i]))
                    //    {
                    //        liste.Remove(Çıkacak[i]);
                    //        if (liste.Count == 0)
                    //        {
                    //            KeysToRemove.Add(key);
                    //        }
                    //    }
                    //}
                }

                //foreach (int key in KeysToRemove)
                //{
                //    Grid.Remove(key);
                //}


                Arşiv.Add(Çözüm);

                //grid yeniden belirlenecek mi

                if (Çözüm.Energy < minEnergy)
                {
                    minEnergy = Çözüm.Energy;
                    ReOrganize = true;
                }
                if (Çözüm.Energy > maxEnergy)
                {
                    maxEnergy = Çözüm.Energy;
                    ReOrganize = true;
                }
                if (Çözüm.Tardiness < minTardiness)
                {
                    minTardiness = Çözüm.Tardiness;
                    ReOrganize = true;
                }
                if (Çözüm.Tardiness > maxTardiness)
                {
                    maxTardiness = Çözüm.Tardiness;
                    ReOrganize = true;
                }

                //if (ReOrganize)
                //{
                //GridBelirle(Archive);
                //}
                //else
                //{
                //    int IndexGrid = GetGridIndex(Çözüm);
                //    if (!Grid.ContainsKey(IndexGrid))
                //        Grid[IndexGrid] = new List<int>();
                //    Grid[IndexGrid].Add(Archive.Count - 1);
                //}

                if (Arşiv.Count > ArchiveLimit)
                {
                    int Sayı= Grid.OrderByDescending(x => x.Value.Count).First().Value.Count();
                    List<int> CrowdedGrids= new List<int>();
                    foreach (var item in Grid)                    
                        if (item.Value.Count==Sayı)                        
                            CrowdedGrids.Add(item.Key);


                    int MostCrowded = CrowdedGrids[rand.Next(CrowdedGrids.Count)];

                    int Remove = Grid[MostCrowded][rand.Next(Grid[MostCrowded].Count)];
                    if (Arşiv[Remove].Energy == minEnergy || Arşiv[Remove].Energy == maxEnergy)
                        ReOrganize = true;
                    Archive.RemoveAt(Remove);
                    //Grid[MostCrowded].Remove(Remove);
                    //if (Grid[MostCrowded].Count==0)
                    //{
                    //    Grid.Remove(MostCrowded);
                    //}

                }

                MaxMinBelirle(ReOrganize);
                GridBelirle(Archive);

            }

        }

        static void MaxMinBelirle(bool Durum)
        {
            if (!Durum)
                return;
            maxEnergy=Archive.Max(x=> x.Energy);
            minEnergy = Archive.Min(x => x.Energy);
            maxTardiness = Archive.Max(x => x.Tardiness);
            minTardiness = Archive.Min(x => x.Tardiness);
        }
        static int GetGridIndex(Solution Çözüm)
        {
            int Division = 10;

            int IndexEnergy = (int)((Çözüm.Energy - minEnergy) / (maxEnergy - minEnergy) * Division) + 1;
            IndexEnergy = IndexEnergy <= Division ? IndexEnergy : Division;
            int IndexTardiness = (int)((Çözüm.Tardiness - minTardiness) / (maxTardiness - minTardiness) * Division) + 1;
            IndexTardiness = IndexTardiness <= Division ? IndexTardiness : Division;
            int IndexGrid = (IndexTardiness - 1) * Division + IndexEnergy;
            return IndexGrid;
        }
        static void GridBelirle(List<Solution> Arşiv)
        {
            Grid.Clear();
            for (int i = 0; i < Arşiv.Count; i++)
            {
                int IndexGrid = GetGridIndex(Arşiv[i]);
                if (!Grid.ContainsKey(IndexGrid))
                    Grid[IndexGrid] = new List<int>();
                Grid[IndexGrid].Add(i);
            }

        }
        static void SelectParents()
        {
            selectedParents.Clear();
            // Tournament Selection                   
            int numberOfTournaments = offspringSize;

            for (int t = 0; t < numberOfTournaments; t++)
            {
                int candidate1, candidate2;

                // Select unique candidates
                do
                {
                    candidate1 = rand.Next(populationSize);
                    candidate2 = rand.Next(populationSize);
                } while (candidate1 == candidate2 || selectedParents.Contains(candidate1) || selectedParents.Contains(candidate2));
                //} while (candidate1 == candidate2);

                //Console.WriteLine($"Tournament {t + 1}: Candidate {candidate1} and Condidate {candidate2}");

                int front1 = GetFrontIndex(candidate1, fronts);
                int front2 = GetFrontIndex(candidate2, fronts);

                int Parent;

                if (front1 < front2) // Candidate 1 is from a better front                        
                    Parent = candidate1;
                else if (front1 > front2) // Candidate 2 is from a better front                        
                    Parent = candidate2;
                else // Candidates are from the same front
                {
                    // Compare crowding distances
                    if (crowdingDistance[candidate1] > crowdingDistance[candidate2])
                        Parent = candidate1;
                    else if (crowdingDistance[candidate1] < crowdingDistance[candidate2])
                        Parent = candidate2;
                    else // They have equal crowding distances            
                         // Handle the equality by selecting one randomly
                        Parent = rand.Next(2) == 0 ? candidate1 : candidate2;
                }

                selectedParents.Add(Parent); // Mark the winner as selected
            }
        }

        static void SelectLeaders()
        {

            //bool AlfaSelect = false, BetaSelect = false, DeltaSelect = false;
            //GridBelirle(Archive);
            int[] Crowd = new int[Archive.Count];
            foreach (List<int> liste in Grid.Values)
            {
                for (int i = 0; i < liste.Count; i++)
                {
                    Crowd[liste[i]] = liste.Count;
                }
            }

            List<int> Candidates = new List<int>();
            List<int> Leaders = new List<int>();
            int x;
            for (int sayı = 1; sayı <= Archive.Count && Leaders.Count < 3; sayı++)
            {
                for (int i = 0; i < Crowd.Length; i++)
                    if (Crowd[i] == sayı)
                        Candidates.Add(i);

                if (Candidates.Count == 1)
                {
                    Leaders.Add(Candidates[0]);
                    Candidates.Clear();
                }
                else if (Candidates.Count == 2)
                {
                    if (Leaders.Count < 2)
                    {
                        Leaders.Add(Candidates[0]);
                        Leaders.Add(Candidates[1]);
                    }
                    else if (Leaders.Count == 2)
                    {
                        Leaders.Add(Candidates[0]);
                    }
                    Candidates.Clear();
                }
                else if (Candidates.Count > 2)
                {
                    int y = Leaders.Count;
                    for (int j = 0; j < 3 - y; j++)
                    {
                        x = rand.Next(Candidates.Count);
                        Leaders.Add(Candidates[x]);
                        Candidates.RemoveAt(x);
                    }

                }

            }

            alfa = Leaders[0];
            beta = Leaders[1];
            delta = Leaders[2];

            AlfaKurt = new Solution();
            BetaKurt = new Solution();
            DeltaKurt = new Solution();

            for (int i = 0; i < AlfaKurt.Sequence.Length; i++)
            {
                AlfaKurt.Sequence[i] = Archive[alfa].Sequence[i];
                AlfaKurt.Hız[i] = Archive[alfa].Hız[i];

                BetaKurt.Sequence[i] = Archive[beta].Sequence[i];
                BetaKurt.Hız[i] = Archive[beta].Hız[i];

                DeltaKurt.Sequence[i] = Archive[delta].Sequence[i];
                DeltaKurt.Hız[i] = Archive[delta].Hız[i];
            }


        }

    }





}

