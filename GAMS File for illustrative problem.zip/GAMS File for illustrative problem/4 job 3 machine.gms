$stitle Example Model Definitions
set
i is indeksi /1*4/
k makine indeksi /1*3/
h makine hizlarin indeksi /1,2,3/

r       'objective functions' / Energyconsumption, Tardiness/

alias (i,l)
alias (k,q);


$set min -1
$set max +1

Parameter dir(r) 'direction of the objective functions'
                 / Energyconsumption %min%, Tardiness %min%/;

scalar M /100000/;

parameter
MB(k) k makinesinin ON-OFF durumu karala�t�racak de�er
/
1  7
2  10
3  8
/;


parameter
SM(k) bosta kalma suresi boyunca standby modunda k makinesinin anlik gucu /
1 3
2 2
3 4
/;

parameter
P(k,h) her hangi i isinin islenmesi sirasinda k makinesinin anlik gucu /
1.1   6
1.2   8
1.3   13

2.1   4
2.2   5
2.3   9

3.1   8
3.2   11
3.3   18
/;

parameter
OS(i,k)/
1.3    1
1.1    2
1.2    3

2.3    1
2.2    2
2.1    3

3.2    1
3.1    2
3.3    3

4.1    1
4.2    2
4.3    3
/;


parameter
BT(i,k) i isi k makinesinde temel isleme suresi /
1.1  43
1.2  2
1.3  48

2.1  33
2.2  7
2.3  29

3.1  62
3.2  66
3.3  61

4.1  14
4.2  72
4.3  99
/;

parameter
speed(h)
/
1  1
2  1.1
3  1.3
/;

parameter AT(i,k,h) i isi k makinesinde h hiziyla fiili isleme suresi;
AT(i,k,h)=round(BT(i,k)/speed(h),2);

parameter
dd(i) i isinin teslim suresi /
1  101
2  66
3  182
4  145

/;

variables
w(r)      'objective function variables'
X(i,k,h) eger i isi k makinesinde h hiziyla islenyorsa 1 degilse 0
Z(i,l,k) eger k makinesinde i ile l i�leri arda��ksa 1 degilse 0
Y(i,l,k)  eger k makinesinde i ile l i�lerin arasinda OFF varsa 1 degilse 0
S(i,k)   i isinin k makinesinde baslama zamani
F(k)     cizlgenin bitiminde makineyi tamamen kapatma zamani
T(i)     i isinin gecikmesi
IdleTime(i,l,k)
StandbyTime(i,l,k)
;
binary variables
X(i,k,h)
Z(i,l,k)
Y(i,l,k)

;

positive variables
S(i,k)
IdleTime(i,l,k)
StandbyTime(i,l,k)
T(i)
;

equation
objenerji   'Enerji t�ketimini minimize etme  amaci'
objtardiness    'Toplam gecikmeyi minimize etme  amaci'
kisit1
kisit2
kisit3
kisit4
kisit5
kisit6
kisit7
kisit8
kisit9
kisit10
kisit11
kisit12
kisit13
kisit14
kisit15
;


objenerji ..    w('Energyconsumption') =e= sum((i,k,h),  X(i,k,h) * P(k,h) * AT(i,k,h)) + sum(k, SM(k)* (sum((i,l) $  ( ord(i) ne ord(l)), StandbyTime(i,l,k)) ))    ;


objtardiness ..    w('Tardiness') =e= sum(i, T(i)) ;


kisit1(i,k)..                                                                      sum(h,X(i,k,h)) =e= 1;


kisit2(i,k,q) $ ( OS(i,q) - OS(i,k) eq 1  ) ..                                     S(i,q) - S(i,k) -  sum(h,X(i,k,h) * AT(i,k,h)) =g= 0;


kisit3(i,l,k) $ ( ord(i) ne ord(l) )..                                             S(l,k) - S(i,k) - sum(h, X(i,k,h) * AT(i,k,h)) + M *(1 - Z(i,l,k)) =g= 0;


kisit4(k) ..                                                                       sum((i,l) $ (ord(i) ne ord(l)) , Z(i,l,k)) =e= card(i) - 1 ;


kisit5(i,k)..                                                                      sum(l $ ( ord(i) ne ord(l)), Z(i,l,k)  ) =l= 1 ;


kisit6(i,k)..                                                                      sum(l $ ( ord(i) ne ord(l)), Z(l,i,k)  ) =l= 1 ;


kisit7(i,k)$ ( OS(i,k) eq card(k))..                                               T(i) =g= S(i,k) + sum(h, X(i,k,h) * AT(i,k,h)) - dd(i);


kisit8(i,l,k)  $  ( ord(i) ne ord(l))..                                            IdleTime(i,l,k) =l= S(l,k)  - S(i,k) - sum( h, X(i,k,h) * AT(i,k,h))  +  M * (1 - Z(i,l,k)) ;


kisit9(i,l,k)  $  ( ord(i) ne ord(l))..                                            IdleTime(i,l,k) =g= S(l,k)  - S(i,k) - sum( h, X(i,k,h) * AT(i,k,h))  -  M * (1 - Z(i,l,k)) ;


kisit10(i,l,k)  $  ( ord(i) ne ord(l))..                                           IdleTime(i,l,k) =l=  M * Z(i,l,k);


kisit11(i,l,k)  $  ( ord(i) ne ord(l))..                                           IdleTime(i,l,k)  =l= MB(k) - 1  + M * Y(i,l,k);


kisit12(i,l,k)  $  ( ord(i) ne ord(l))..                                           IdleTime(i,l,k) =g=  MB(k) - M * ( 1 - Y(i,l,k) );


kisit13(i,l,k)  $  ( ord(i) ne ord(l))..                                           StandbyTime(i,l,k) =l= IdleTime(i,l,k) + M *Y (i,l,k);


kisit14(i,l,k)  $  ( ord(i) ne ord(l))..                                           StandbyTime(i,l,k) =g= IdleTime(i,l,k) - M *Y (i,l,k); ;


kisit15(i,l,k)  $  ( ord(i) ne ord(l))..                                           StandbyTime(i,l,k) =l= M*(1 - Y(i,l,k))  ;



model tik_uygulama/all/;
tik_uygulama.optfile=1;
$onecho>cplex.opt
threads = -1
$offecho
option optcr = 0;
option reslim = 10800;
option iterlim = 1e9;



Set
r1(r)  'the first element of r'
rm1(r) 'all but the first elements of r'
rr(r)  'active objective function in constraint allobj';
r1(r)$(ord(r) = 1) = yes;
rm1(r) = yes;
rm1(r1) = no;
Parameter
rhs(r)    'right hand side of the constrained obj functions in eps-constraint'
maxobj(r) 'maximum value from the payoff table'
minobj(r) 'minimum value from the payoff table'
numr(r)   'ordinal value of r starting with 1';
Scalar
iter         'total number of iterations'
infeas       'total number of infeasibilities'
elapsed_time 'elapsed time for payoff and e-sonstraint'
starting        'start time'
finishing       'finish time';
Variable
a_objval 'auxiliary variable for the objective function'
objective 'auxiliary variable during the construction of the payoff table'
sl(r)    'slack or surplus variables for the eps-constraints';
positive variable sl;
Equation
con_obj(r) 'constrained objective functions'
augm_obj   'augmented objective function to avoid weakly efficient solutions'
allobj     'all the objective functions in one expression';
con_obj(rm1)..w(rm1) - dir(rm1) * sl(rm1) =e= rhs(rm1);
augm_obj..sum(r1, dir(r1) * w(r1)) + 1e-3 * sum(rm1, sl(rm1) / (maxobj(rm1) - minobj(rm1))) =e= a_objval;
allobj..sum(rr, dir(rr) * w(rr)) =e= objective;
Model
mod_payoff / tik_uygulama, allobj /
mod_epsmethod / tik_uygulama, con_obj, augm_obj /;
Parameter payoff(r, r) 'payoff tables entries';
Alias(r, rp);
loop(rp,
rr(rp) = yes;
repeat
solve mod_payoff using mip maximizing objective ;
payoff(rp, rr) = w.l(rr);
w.fx(rr) = w.l(rr);
rr(r++1) = rr(r);
until rr(rp);
rr(rp) = no;
w.up(r) = inf;
w.lo(r) = -inf;
);
if (mod_payoff.modelStat <> %modelStat.optimal% and
mod_payoff.modelStat <> 8,
abort 'no feasible solution for mod_payoff');
File fx / solutions.txt /;
put fx ' PAYOFF TABLE' /;
loop(rp,
loop(r, put payoff(rp, r):12:2;);
put /;
);
display payoff;
minobj(r) = smin(rp, payoff(rp, r));
maxobj(r) = smax(rp, payoff(rp, r));
$if not set gridpoints $set gridpoints 10
Set
g         'grid points' / g0*g%gridpoints% /
grid(r, g) 'grid';
Parameter
gridrhs(r, g) 'RHS of eps-constraint at grid point'
maxg(r)      'maximum point in grid for objective'
posg(r)      'grid position of objective'
firstOffMax  'some counters'
lastZero     'some counters'
 numg(g)      'ordinal value of g starting with 0'
step(r)      'step of grid points in objective functions'
jump(r)      'jumps in the grid points traversing';
lastZero = 1;
loop(rm1,
numr(rm1) = lastZero;
lastZero
= lastZero + 1;
);
numg(g) = ord(g) - 1;
grid(rm1, g) = yes;
maxg(rm1) = smax(grid(rm1, g), numg(g));
step(rm1) = (maxobj(rm1) - minobj(rm1)) / maxg(rm1);
gridrhs(grid(rm1, g))$(dir(rm1) = -1) = maxobj(rm1) - numg(g) / maxg(rm1) * (maxobj(rm1) - minobj(rm1));
gridrhs(grid(rm1, g))$(dir(rm1) = 1) = minobj(rm1) + numg(g) / maxg(rm1) * (maxobj(rm1) - minobj(rm1));
put fx ' Grid points' /;
loop(g,
loop(rm1, put gridrhs(rm1, g):12:2;);
put /;
);
display gridrhs;
put / 'Efficient solutions' /;
posg(rm1) = 0;
iter = 0;
infeas = 0;
starting = jnow;
repeat
rhs(rm1) = sum(grid(rm1, g)$(numg(g) = posg(rm1)), gridrhs(rm1, g));
solve mod_epsmethod maximizing a_objval using mip;
iter = iter + 1;
if (mod_epsmethod.modelStat <>%modelStat.optimal% and
mod_epsmethod.modelStat <>%modelStat.integer Solution%,
infeas = infeas + 1;
put iter:5:0, '  infeasible' /;
lastZero = 0;
loop(rm1$(posg(rm1) > 0 and lastZero = 0), lastZero = numr(rm1));
posg(rm1)$(numr(rm1) <= lastZero) = maxg(rm1);
else
put iter:5:0;
loop(r, put w.l(r):12:2;);
jump(rm1) = 1;
jump(rm1)$(numr(rm1) = 1) = 1 + floor(sl.L(rm1) / step(rm1));
loop(rm1$(jump(rm1) > 1), put '   jump';);
put /;
);
firstOffMax = 0;
loop(rm1$(posg(rm1) < maxg(rm1) and firstOffMax = 0),
posg(rm1) = min((posg(rm1) + jump(rm1)), maxg(rm1));
firstOffMax = numr(rm1);
);
posg(rm1)$(numr(rm1) < firstOffMax) = 0;
abort$(iter > 1000) 'more than 1000 iterations, something seems to go wrong';

until sum(rm1$(posg(rm1) = maxg(rm1)),1) = card(rm1) and firstOffMax = 0;
finishing = jnow;
elapsed_time = (finishing - starting) * 60 * 60 * 24;
put /;
put 'Infeasibilities = ', infeas: 5:0 /;
put 'Elapsed time: ',elapsed_time: 10:2, ' seconds' /;



